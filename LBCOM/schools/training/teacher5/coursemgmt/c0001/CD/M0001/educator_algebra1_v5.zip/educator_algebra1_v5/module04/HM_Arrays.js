//
HM_Array1 = [
["175",100,20,],
["Module 1","../module02/02_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]

HM_Array2 = [
["175",180,20,],
["Module 4 Itinerary","04_00.htm",1,0,0],
["04.00 Pretest","04_00a.htm",1,0,0],
["04.01 Rules","04_01a.htm",1,0,0],
["04.01H Honors","04_01ha.htm",1,0,0],
["04.02 Simplify","04_02a.htm",1,0,0],
["04.03 Equations","04_03a.htm",1,0,0],
["04.04 Advanced Equations","04_04a.htm",1,0,0],
["04.05 Solving Equations with Fractions","04_05a.htm",1,0,0],
["04.06 Quiz 2","04_06.htm",1,0,0],
["04.07 Absolute Value Equations","04_07a.htm",1,0,0],
["04.08 Literal","04_08a.htm",1,0,0],
["04.09 Variation","04_09a.htm",1,0,0],
["04.10 Quiz 3","04_10.htm",1,0,0],
["04.11 Functions","04_11a.htm",1,0,0],
["04.12 Functional Notation","04_12a.htm",1,0,0],
["04.13 Honors","04_13a.htm",1,0,0],
["04.14 Lab","04_14a.htm",1,0,0],
["04.15 Quiz 3","04_15.htm",1,0,0],
["04.16 Practice Problems","04_16a.htm",1,0,0],
["04.17 Practice Test","04_17.htm",1,0,0],
["04.18 Oral Assessment","04_18.htm",1,0,0],
["04.19 Module Test","04_19.htm",1,0,0],
["04.20 Module Survey","04_20.htm",1,0,0]
]
