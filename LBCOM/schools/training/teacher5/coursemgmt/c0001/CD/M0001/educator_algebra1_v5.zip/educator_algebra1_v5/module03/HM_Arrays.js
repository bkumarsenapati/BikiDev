//
HM_Array1 = [
["175",100,20,],
["Module 1","../module01/01_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]


HM_Array2 = [
["175",180,20,],
["Module 3 Itinerary","03_00.htm",1,0,0],
["03.00 Pretest","03_00a.htm",1,0,0],
["03.01 Number System Relationships","03_01a.htm",1,0,0],
["03.02 Integers","03_02a.htm",1,0,0],
["03.03 PEMDAS","03_03a.htm",1,0,0],
["03.04 Quiz 1","03_04.htm",1,0,0],
["03.05 Absolute Value","03_05a.htm",1,0,0],
["03.06 Exponents","03_06a.htm",1,0,0],
["03.07 Evaluating Expressions","03_07a.htm",1,0,0],
["03.08 Connections","03_08a.htm",1,0,0],
["03.09 Quiz 2","03_09.htm",1,0,0],
["03.10 Lab","03_10a.htm",1,0,0],
["03.11 Practice Test","03_11.htm",1,0,0],
["03.12 Module Review and Test","03_12a.htm",1,0,0],
["03.13 Module Survey","03_13.htm",1,0,0]
]