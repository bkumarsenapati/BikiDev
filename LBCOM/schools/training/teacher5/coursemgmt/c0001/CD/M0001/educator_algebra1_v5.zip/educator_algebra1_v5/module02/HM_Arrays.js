//
HM_Array1 = [
["175",100,20,],
["Module 1","../module01/01_00.htm",1,0,0],
["Module 2","02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]


HM_Array2 = [
["175",180,20,],
["Module 2 Itinerary","02_00.htm",1,0,0],
["02.01 Tables","02_01a.htm",1,0,0],
["02.02 Graphs","02_02a.htm",1,0,0],
["02.03 Charts","02_03a.htm",1,0,0],
["02.04 Problems","02_04a.htm",1,0,0],
["02.05 Lab","02_05a.htm",1,0,0],
["02.06 Lose It if You Don't Use It","02_06a.htm",1,0,0],
["02.07 Module Survey","02_07.htm",1,0,0],
["02.08 Module Test","02_08.htm",1,0,0]
]