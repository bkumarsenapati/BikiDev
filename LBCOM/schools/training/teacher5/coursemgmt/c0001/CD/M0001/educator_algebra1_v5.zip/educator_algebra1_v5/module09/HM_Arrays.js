//
HM_Array1 = [
["175",100,20,],
["Module 1","../module01/01_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]


HM_Array2 = [
["175",180,20,],
["Module 9 Itinerary","09_00.htm",1,0,0],
["09.00 Pretest Module 9","09_00a.htm",1,0,0],
["09.01 Lab","09_01.htm",1,0,0],
["09.02 Inequalities","09_02a.htm",1,0,0],
["09.03 Graphing","09_03a.htm",1,0,0],
["09.04 HONORS Graphing","09_04a.htm",1,0,0],
["09.05 Quiz 1","09_05.htm",1,0,0],
["09.06 Graphing Linear Equations Review","09_06a.htm",1,0,0],
["09.07 Systems","09_07a.htm",1,0,0],
["09.08 HONORS Problems","09_08a.htm",1,0,0],
["09.09 Thinking","09_09a.htm",1,0,0],
["09.10 Practice Test","09_10.htm",1,0,0],
["09.11 Oral Assessment","09_11.htm",1,0,0],
["09.12 Module Test","09_12.htm",1,0,0],
["09.13 Module Survey","09_13.htm",1,0,0]
]