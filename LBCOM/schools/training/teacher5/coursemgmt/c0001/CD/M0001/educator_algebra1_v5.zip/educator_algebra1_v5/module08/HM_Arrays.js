//
HM_Array1 = [
["175",100,20,],
["Module 1","../module01/01_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]

HM_Array2 = [
["175",180,20,],
["Module 8 Itinerary","08_00.htm",1,0,0],
["08.00 Pretest","08_00a.htm",1,0,0],
["08.01 Simplifying Expressions","08_01a.htm",1,0,0],
["08.02 Multiplying and Dividing Expressions","08_02a.htm",1,0,0],
["08.03 Quiz 1","08_03.htm",1,0,0],
["08.04 Adding and Subtracting Expressions","08_04a.htm",1,0,0],
["08.05 HONORS","08_05a.htm",1,0,0],
["08.06 Solving Equations","08_06a.htm",1,0,0],
["08.07 HONORS Part 2","08_07a.htm",1,0,0],
["08.08 Quiz 2","08_08.htm",1,0,0],
["08.09 Lab","08_09a.htm",1,0,0],
["08.10 Field Trip","08_10.htm",1,0,0],
["08.11 Practice Test","08_11.htm",1,0,0],
["08.12 Test","08_12.htm",1,0,0],
["08.13 Module Survey","08_13.htm",1,0,0]
]