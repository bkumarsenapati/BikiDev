//
HM_Array1 = [
["175",100,20,],
["Module 1","../module01/01_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]

HM_Array2 = [
["175",180,20,],
["Module 7 Itinerary","07_00.htm",1,0,0],
["07.00 Pretest","07_00a.htm",1,0,0],
["07.01 GCF","07_01a.htm",1,0,0],
["07.02 Difference of Squares","07_02a.htm",1,0,0],
["07.03 Factoring by Grouping","07_03a.htm",1,0,0],
["07.04 Trinomials","07_04a.htm",1,0,0],
["07.05 Quiz 1","07_05.htm",1,0,0],
["07.06 Trinomials Part 2","07_06a.htm",1,0,0],
["07.07 Factoring Completely","07_07a.htm",1,0,0],
["07.08 Solving Equations by Factoring","07_08a.htm",1,0,0],
["07.09 Quadratic Formula","07_09a.htm",1,0,0],
["07.10 HONORS Lab","07_10a.htm",1,0,0],
["07.11 Discriminant","07_11a.htm",1,0,0],
["07.12 Practice Test","07_12.htm",1,0,0],
["07.13 Oral Assignment","07_13.htm",1,0,0],
["07.14 Module Test","07_14.htm",1,0,0],
["07.15 Module Survey","07_15.htm",1,0,0]
]
