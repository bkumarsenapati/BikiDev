//
HM_Array1 = [
["175",80,20,],
["Module 1","01_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]


HM_Array2 = [
["175",150,20,],
["Module 10 Itinerary","10_00.htm",1,0,0],
["10.01 Review","10_01a.htm",1,0,0],
["10.02 Review","10_02a.htm",1,0,0],
["10.03 Review","10_03a.htm",1,0,0],
["10.04 Final Exam","10_04.htm",1,0,0]
]