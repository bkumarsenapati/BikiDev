//
HM_Array1 = [
["175",100,20,],
["Module 1","01_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]


HM_Array2 = [
["175",180,20,],
["Module 1 Itinerary","01_00.htm",1,0,0],
["01.01 Motif and Course Information","01_01a.htm",1,0,0],
["01.02 Navigating the Course","01_02.htm",1,0,0],
["01.03 Pace","01_03a.htm",1,0,0],
["01.04 Travel To Do List","01_04.htm",1,0,0],
["01.05 Submitting Travelogues","01_05a.htm",1,0,0],
["01.06 Effective Learning Resources","01_06.htm",1,0,0],
["01.07 Summary Assignment","01_07.htm",1,0,0],
["01.08 Diagnostic Test","01_08.htm",1,0,0],
["01.09 Module Survey","01_08.htm",1,0,0]
]

