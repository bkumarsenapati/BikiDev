//
HM_Array1 = [
["175",0,20,],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0]
]

HM_Array2 = [
["175",80,20,],
["Step by Step Chart","#",1,0,0],
["04 Pre/Post Test","#",1,0,0],
["04.00 Websearch","#",1,0,0],
["04.01 Writing","#",1,0,0],
["04.02 Rules","#",1,0,0],
["04.02 Honors","#",1,0,0],
["04.03 Simplify","#",1,0,0],
["04.04 Equations","#",1,0,0],
["04.04Q Quiz 1","#",1,0,0],
["04.05 Abs. Value","#",1,0,0],
["04.06 Literal","#",1,0,0],
["04.07 Variation","#",1,0,0],
["04.07Q Quiz 2","#",1,0,0],
["04.08 Functions","#",1,0,0],
["04.09 Honors","#",1,0,0],
["04.10 Lab","#",1,0,0],
["04.10Q Quiz 3","#",1,0,0],
["04.11 Problems","#",1,0,0],
["04.12 Reflections","#",1,0,0],
["04.12P Practice Test","#",1,0,0],
["04.12T Test","#",1,0,0]
]

HM_Array3 = [
["175",220,20,],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0],
["Module 1 Technology","#",1,0,0]
]