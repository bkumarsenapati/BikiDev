//
HM_Array1 = [
["175",100,20,],
["Module 1","../module01/01_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","05_00.htm",1,0,0],
["Module 6","../module06/06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]

HM_Array2 = [
["175",180,20,],
["Module 5 Itinerary","05_00.htm",1,0,0],
["05.00 Pretest","05_00a.htm",1,0,0],
["05.01 Linear Equations","05_01a.htm",1,0,0],
["05.02 Slope and Intercepts","05_02a.htm",1,0,0],
["05.03 Advanced Slope","05_03a.htm",1,0,0],
["05.04 Special Lines","05_04a.htm",1,0,0],
["05.05 Quiz 1","05_05.htm",1,0,0],
["05.06 Writing Equations of Lines","05_06a.htm",1,0,0],
["05.07 Graphing Linear Equations","05_07a.htm",1,0,0],
["05.08 Honors","05_08a.htm",1,0,0],
["05.09 Quiz 2","05_09.htm",1,0,0],
["05.10 Lab","05_10a.htm",1,0,0],
["05.11 Solving Systems of Equations","05_11a.htm",1,0,0],
["05.12 Systems of Equations Part 2","05_12a.htm",1,0,0],
["05.13 Substitution Method","05_13a.htm",1,0,0],
["05.14 HONORS Word Problems","05_14a.htm",1,0,0],
["05.15 Field Trip","05_15.htm",1,0,0],
["05.16 Practice Test","05_16.htm",1,0,0],
["05.17 Oral Assignment","05_17.htm",1,0,0],
["05.18 Module Test","05_18.htm",1,0,0],
["05.19 Module Survey","05_19.htm",1,0,0],
["05.20 Semester Exam Review","05_20a.htm",1,0,0]
]
