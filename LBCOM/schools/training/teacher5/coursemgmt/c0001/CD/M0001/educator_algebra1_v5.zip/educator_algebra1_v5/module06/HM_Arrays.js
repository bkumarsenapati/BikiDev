//
HM_Array1 = [
["175",100,20,],
["Module 1","../module01/01_00.htm",1,0,0],
["Module 2","../module02/02_00.htm",1,0,0],
["Module 3","../module03/03_00.htm",1,0,0],
["Module 4","../module04/04_00.htm",1,0,0],
["Module 5","../module05/05_00.htm",1,0,0],
["Module 6","06_00.htm",1,0,0],
["Module 7","../module07/07_00.htm",1,0,0],
["Module 8","../module08/08_00.htm",1,0,0],
["Module 9","../module09/09_00.htm",1,0,0],
["Module 10","../module10/10_01a.htm",1,0,0]
]

HM_Array2 = [
["175",180,20,],
["Module 6 Itinerary","06_00.htm",1,0,0],
["06.00 Pretest","06_00a.htm",1,0,0],
["06.01 Add Polys","06_01a.htm",1,0,0],
["06.02 Multiplication/Division of Polys","06_02a.htm",1,0,0],
["06.03 Powers","06_03a.htm",1,0,0],
["06.04 FOIL","06_04a.htm",1,0,0],
["06.05 Quiz 1","06_05.htm",1,0,0],
["06.06 Roots","06_06a.htm",1,0,0],
["06.07 Multiplying and Dividing Roots","06_07a.htm",1,0,0],
["06.08 Quiz 2","06_08.htm",1,0,0],
["06.09 Addition/Subtraction of Radicals","06_09a.htm",1,0,0],
["06.10 Pythagorean Theorem","06_10a.htm",1,0,0],
["06.11 Quiz 3","06_11.htm",1,0,0],
["06.12 Lab","06_12a.htm",1,0,0],
["06.13 Practice Test","06_13.htm",1,0,0],
["06.14 Module Test","06_14.htm",1,0,0],
["06.15 Module Survey","06_15.htm",1,0,0]
]